<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PendaftaranModel;
use App\Models\MahasiswaModel;
use Illuminate\Support\Facades\Storage;

class VerifikasiController extends Controller
{
    /**
     * Display a listing of registrations for verification.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Get all registrations with their related student data
        $pendaftarans = PendaftaranModel::with('mahasiswa')->get();
        
        // Set active menu for sidebar
        $activeMenu = 'verifikasi';
        
        // Data for breadcrumb
        $breadcrumb = (object) [
            'title' => 'Verifikasi Pendaftaran',
            'list' => ['Home', 'Verifikasi']
        ];

        $page = (object) [
            'title' => 'Verifikasi Pendaftaran TOEIC'
        ];
        
        return view('verifikasi.index', compact('pendaftarans', 'activeMenu', 'breadcrumb', 'page'));
    }

    /**
     * Display the specified registration for verification.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        // Find the registration by ID with its related student data
        $pendaftaran = PendaftaranModel::with('mahasiswa')->findOrFail($id);
        
        // Set active menu for sidebar
        $activeMenu = 'verifikasi';
        
        // Data for breadcrumb
        $breadcrumb = (object) [
            'title' => 'Detail Pendaftaran',
            'list' => ['Home', 'Verifikasi', 'Detail']
        ];

        $page = (object) [
            'title' => 'Detail Pendaftaran TOEIC'
        ];
        
        return view('verifikasi.show', compact('pendaftaran', 'activeMenu', 'breadcrumb', 'page'));
    }

    /**
     * Update the verification status of a registration.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function verify(Request $request, $id)
    {
        // Validate the request data
        $request->validate([
            'status' => 'required|in:approved,rejected,pending'
        ]);

        // Find the registration by ID
        $pendaftaran = PendaftaranModel::findOrFail($id);
        
        // Update the verification status
        $pendaftaran->status_verifikasi = $request->status;
        $pendaftaran->keterangan = $request->keterangan;
        $pendaftaran->save();

        // Redirect back to the verification list with a success message
        return redirect()->route('verifikasi.index')
            ->with('success', 'Status pendaftaran berhasil diperbarui');
    }
    
    /**
     * Download the specified file from a registration.
     *
     * @param  int  $id
     * @param  string  $type
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function downloadFile($id, $type)
    {
        $pendaftaran = PendaftaranModel::findOrFail($id);
        
        $fileColumn = '';
        switch ($type) {
            case 'ktp':
                $fileColumn = 'file_ktp';
                break;
            case 'ktm':
                $fileColumn = 'file_ktm';
                break;
            case 'foto':
                $fileColumn = 'file_foto';
                break;
            case 'bukti':
                $fileColumn = 'file_bukti_pembayaran';
                break;
            default:
                abort(404, 'File tidak ditemukan');
        }
        
        if (!$pendaftaran->$fileColumn) {
            abort(404, 'File tidak ditemukan');
        }
        
        $path = storage_path('app/' . $pendaftaran->$fileColumn);
        
        if (!file_exists($path)) {
            abort(404, 'File tidak ditemukan');
        }
        
        return response()->download($path);
    }
}
